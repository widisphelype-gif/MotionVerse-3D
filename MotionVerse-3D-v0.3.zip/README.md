# MotionVerse 3D

Arcade desktop 3D controlado por movimentos capturados pela webcam. Projeto para Windows 10/11, usando Electron, Three.js e MediaPipe Tasks Vision.

## Recursos do protótipo 0.3.0
- Interface desktop renovada em tema escuro/neon.
- Quatro experiências iniciais: Neon Catch, Body Dodge, Gesture Magic e Balance Lab.
- Rastreamento independente de até duas mãos, pose corporal e rosto.
- Aplicativo Windows com instalador NSIS e executável portátil.

> As mecânicas ainda são protótipos em desenvolvimento. A primeira inicialização precisa de internet para carregar os modelos de visão computacional e os recursos de interface externos.

## Executar em desenvolvimento

```bash
npm install
npm run desktop:dev
```

## Gerar executáveis no Windows

```bash
npm install
npm run package:win
```

Os arquivos `.exe` serão gerados em `release/`.

## Gerar pelo GitHub Actions
1. Abra a aba **Actions** deste repositório.
2. Selecione **Build MotionVerse for Windows**.
3. Clique em **Run workflow** e confirme.
4. Quando terminar, abra a execução e baixe o artefato **MotionVerse-3D-Windows**.

O artefato contém o instalador e a versão portátil quando ambos forem gerados pelo electron-builder.

## Privacidade
A captura e a inferência da webcam acontecem localmente no aplicativo. Os modelos são baixados de fontes públicas na primeira execução; o vídeo não é enviado por este projeto.
