import './style.css';
import * as THREE from 'three';
import { FilesetResolver, HandLandmarker, PoseLandmarker, FaceLandmarker } from '@mediapipe/tasks-vision';

const $ = (id) => document.getElementById(id);
const video = $('webcam'), sceneHost = $('scene');
let stream = null, handsTask = null, poseTask = null, faceTask = null;
let tracking = false, lastVideoTime = -1, currentGame = 'catch';
let score = 0, timeLeft = 60, gameRunning = false, timerId = null;
let poseX = 0, handX = 0, handY = 0, handsVisible = false, bodyVisible = false, faceVisible = false;
let renderer, scene, camera, clock, player, orbs = [], obstacles = [], magicRing;
const gameInfo = {
 catch: ['Neon Catch','Mova as mãos para alcançar os orbes.'],
 dodge: ['Body Dodge','Incline o tronco para escapar dos obstáculos.'],
 magic: ['Gesture Magic','Aproxime as mãos para carregar energia.'],
 balance: ['Balance Lab','Mantenha o centro do corpo alinhado.']
};

function init3D(){
 scene = new THREE.Scene(); scene.fog = new THREE.Fog(0x091321,8,22);
 camera = new THREE.PerspectiveCamera(48,1,.1,100); camera.position.set(0,2.4,8.5); camera.lookAt(0,1,0);
 renderer = new THREE.WebGLRenderer({antialias:true,alpha:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(sceneHost.clientWidth,sceneHost.clientHeight); renderer.shadowMap.enabled=true; renderer.outputColorSpace=THREE.SRGBColorSpace; sceneHost.appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0x9bc9ff,0x101525,2));
 const key=new THREE.DirectionalLight(0xffffff,2.2);key.position.set(3,7,5);key.castShadow=true;scene.add(key);
 const floor=new THREE.Mesh(new THREE.CircleGeometry(5,64),new THREE.MeshStandardMaterial({color:0x13243b,metalness:.45,roughness:.55}));floor.rotation.x=-Math.PI/2;floor.position.y=-.05;floor.scale.set(1.4,1,1);scene.add(floor);
 const grid=new THREE.GridHelper(14,28,0x3c6b8e,0x20344d);grid.position.y=-.035;scene.add(grid);
 player=new THREE.Group();
 const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.38,.9,6,12),new THREE.MeshStandardMaterial({color:0xb7ff5a,metalness:.35,roughness:.28}));torso.position.y=1.1;player.add(torso);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.25,24,16),new THREE.MeshStandardMaterial({color:0xd6e6f7,metalness:.2,roughness:.35}));head.position.y=1.85;player.add(head);scene.add(player);
 magicRing=new THREE.Mesh(new THREE.TorusGeometry(.75,.035,12,64),new THREE.MeshBasicMaterial({color:0xb7ff5a,transparent:true,opacity:.8}));magicRing.position.set(0,1.3,-.2);scene.add(magicRing);
 for(let i=0;i<12;i++)spawnOrb();
 for(let i=0;i<5;i++)spawnObstacle();
 clock=new THREE.Clock();window.addEventListener('resize',resize);animate();
}
function spawnOrb(){
 const m=new THREE.Mesh(new THREE.IcosahedronGeometry(.17,2),new THREE.MeshStandardMaterial({color:0xb7ff5a,emissive:0x5b9c16,emissiveIntensity:1.4,metalness:.35,roughness:.2}));
 m.position.set((Math.random()-.5)*7,.5+Math.random()*2.5,-Math.random()*5);scene.add(m);orbs.push(m);
}
function spawnObstacle(){
 const m=new THREE.Mesh(new THREE.BoxGeometry(.65,.65,.65),new THREE.MeshStandardMaterial({color:0xff5a7a,emissive:0x6b1028,emissiveIntensity:.8,metalness:.25,roughness:.35}));
 m.position.set((Math.random()-.5)*7,.55,-4-Math.random()*8);scene.add(m);obstacles.push(m);
}
function resize(){if(!renderer)return;const w=sceneHost.clientWidth,h=sceneHost.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h)}
function setGame(id){
 currentGame=id;gameRunning=false;clearInterval(timerId);timeLeft=60;score=0;
 $('score').textContent='0000';$('gameTitle').textContent=gameInfo[id][0];$('gameHint').textContent=gameInfo[id][1];
 $('gameTime').textContent='01:00';$('startGame').textContent='INICIAR DESAFIO';
 document.querySelectorAll('.game-choice').forEach(b=>b.classList.toggle('selected',b.dataset.game===id));
}
document.querySelectorAll('.game-choice').forEach(b=>b.addEventListener('click',()=>setGame(b.dataset.game)));
function addScore(n=10){score+=n;$('score').textContent=String(score).padStart(4,'0')}
function startGame(){
 if(!tracking){alert('Ative a webcam antes de iniciar um desafio.');return}
 gameRunning=true;timeLeft=60;$('startGame').textContent='DESAFIO EM ANDAMENTO';
 clearInterval(timerId);timerId=setInterval(()=>{if(!gameRunning)return;timeLeft--; $('gameTime').textContent=`00:${String(timeLeft).padStart(2,'0')}`;if(timeLeft<=0){gameRunning=false;clearInterval(timerId);$('startGame').textContent='JOGAR NOVAMENTE';$('gameHint').textContent=`Fim do desafio! Pontuação: ${score}`}},1000);
}
$('startGame').addEventListener('click',startGame);

async function startCamera(){
 try{
  $('startCamera').disabled=true;
  stream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720},facingMode:'user'},audio:false});
  video.srcObject=stream;await video.play();
  const vision=await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22/wasm');
  const common={baseOptions:{delegate:'GPU'},runningMode:'VIDEO'};
  [handsTask,poseTask,faceTask]=await Promise.all([
   HandLandmarker.createFromOptions(vision,{...common,baseOptions:{...common.baseOptions,modelAssetPath:'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'},numHands:2}),
   PoseLandmarker.createFromOptions(vision,{...common,baseOptions:{...common.baseOptions,modelAssetPath:'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task'},numPoses:1}),
   FaceLandmarker.createFromOptions(vision,{...common,baseOptions:{...common.baseOptions,modelAssetPath:'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task'},numFaces:1,outputFaceBlendshapes:false})
  ]);
  tracking=true;$('stopCamera').disabled=false;$('cameraStatus').textContent='CÂMERA ATIVA';document.querySelector('.status-dot').classList.add('on');
  $('webcam').style.display='block';$('trackingState').textContent='ATIVO';
  predict();
 }catch(err){
  console.error(err);stopCamera();alert('Não foi possível iniciar o rastreamento. Confira a permissão da câmera e a conexão com a internet para baixar os modelos de IA.');
 }
}
function stopCamera(){
 tracking=false;gameRunning=false;clearInterval(timerId);
 if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;
 handsTask=poseTask=faceTask=null;
 $('cameraStatus').textContent='CÂMERA DESCONECTADA';document.querySelector('.status-dot').classList.remove('on');$('trackingState').textContent='AGUARDANDO';
 $('handsState').textContent='—';$('bodyState').textContent='—';$('faceState').textContent='—';
 $('startCamera').disabled=false;$('stopCamera').disabled=true;$('webcam').style.display='none';
 $('startGame').textContent='INICIAR DESAFIO';
}
$('startCamera').addEventListener('click',startCamera);$('stopCamera').addEventListener('click',stopCamera);
function predict(){
 if(!tracking||!handsTask||!poseTask||!faceTask)return;
 if(video.currentTime!==lastVideoTime){
  lastVideoTime=video.currentTime;const now=performance.now();
  const h=handsTask.detectForVideo(video,now),p=poseTask.detectForVideo(video,now),f=faceTask.detectForVideo(video,now);
  readTracking(h,p,f);
 }
 requestAnimationFrame(predict);
}
function readTracking(h,p,f){
 const hand=h.landmarks?.[0];const pose=p.landmarks?.[0];const face=f.faceLandmarks?.[0];
 handsVisible=!!h.landmarks?.length;bodyVisible=!!pose;faceVisible=!!face;
 $('handsState').textContent=handsVisible?'DETECTADAS':'NÃO VISTAS';
 $('bodyState').textContent=bodyVisible?'DETECTADO':'NÃO VISTO';
 $('faceState').textContent=faceVisible?'DETECTADO':'NÃO VISTO';
 if(hand){const wrist=hand[0];handX=(.5-wrist.x)*7;handY=(1-wrist.y)*3.3}
 if(pose){const left=pose[11],right=pose[12];poseX=(.5-((left.x+right.x)/2))*6}
 $('trackingState').textContent=(handsVisible||bodyVisible||faceVisible)?'RASTREANDO':'PROCURANDO';
}
function animate(){
 requestAnimationFrame(animate);const t=clock.getElapsedTime();
 const targetX=tracking?(currentGame==='dodge'||currentGame==='balance'?poseX:handX):Math.sin(t*.55)*.6;
 player.position.x=THREE.MathUtils.lerp(player.position.x,targetX,.09);
 player.rotation.z=THREE.MathUtils.lerp(player.rotation.z,tracking?poseX*.12:Math.sin(t)*.08,.08);
 magicRing.rotation.z+=.012;magicRing.scale.setScalar(1+Math.sin(t*2)*.08);
 magicRing.material.opacity=(currentGame==='magic'&&handsVisible)?1:.22;
 orbs.forEach((o,i)=>{
  o.rotation.x+=.012;o.rotation.y+=.018;o.position.y+=Math.sin(t*1.4+i)*.0015;
  if(currentGame==='catch'&&gameRunning&&handsVisible){
   const dx=o.position.x-player.position.x,dy=o.position.y-(.9+handY*.25);
   if(Math.abs(dx)<.55&&Math.abs(dy)<.65&&o.position.z>-1.8){o.position.set((Math.random()-.5)*7,.5+Math.random()*2.5,-Math.random()*5);addScore()}
  }
  if(currentGame==='magic'&&gameRunning&&handsVisible&&faceVisible&&Math.abs(handX)<.35&&Math.abs(handY-1)<.5&&Date.now()%90<16)addScore(1);
 });
 obstacles.forEach(o=>{
  o.position.z+=currentGame==='dodge'&&gameRunning?.055:.012;
  if(o.position.z>2){o.position.z=-8-Math.random()*5;o.position.x=(Math.random()-.5)*7}
  if(currentGame==='dodge'&&gameRunning&&bodyVisible&&Math.abs(o.position.x-player.position.x)<.65&&Math.abs(o.position.z)<.5){o.position.z=-9;addScore(5)}
 });
 if(currentGame==='balance'&&gameRunning&&bodyVisible&&Math.abs(poseX)<.45&&Date.now()%500<18)addScore(1);
 renderer.render(scene,camera);
}
init3D();
