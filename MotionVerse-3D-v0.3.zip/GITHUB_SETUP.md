# Build Windows EXE

O workflow `.github/workflows/build-windows.yml` compila os executáveis em um runner Windows do GitHub Actions.

- Abra **Actions** → **Build MotionVerse for Windows**.
- Clique em **Run workflow**.
- Baixe **MotionVerse-3D-Windows** na seção Artifacts da execução concluída.

Também é possível iniciar o workflow ao enviar uma tag `v*`.
